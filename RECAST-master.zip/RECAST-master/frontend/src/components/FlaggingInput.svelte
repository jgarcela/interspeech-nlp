<!-- TextArea Component -->
<textarea 
class="textarea" 
style="height:10.65em" 
placeholder="e.g. 'How are you?' has a high toxicity score!">
</textarea>
<button class="button is-primary">Submit</button>

